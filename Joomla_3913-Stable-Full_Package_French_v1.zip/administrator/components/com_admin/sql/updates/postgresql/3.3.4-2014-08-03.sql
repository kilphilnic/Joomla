ALTER TABLE "#__user_profiles" ALTER COLUMN "profile_value" TYPE text;
