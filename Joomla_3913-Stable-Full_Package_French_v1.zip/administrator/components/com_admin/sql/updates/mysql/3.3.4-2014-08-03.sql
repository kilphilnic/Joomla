ALTER TABLE `#__user_profiles` CHANGE `profile_value` `profile_value` TEXT NOT NULL;
